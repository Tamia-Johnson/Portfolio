package sample;

        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.SQLException;

public class SQL {




    public static Connection tableConnector()
    {
        try
        {
            Connection connection = null;
            //establish a connection to database
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://192.185.190.96:3306/tjohnson_java2348", "tjohnson_John123", "Blue2018?");
            return connection;
        }

        catch(ClassNotFoundException | SQLException e)
        {
            System.out.println(e);
        }
        return null;
    }

}


