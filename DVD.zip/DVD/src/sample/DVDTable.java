package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class DVDTable
{


        private final StringProperty dvdID;
        private final StringProperty dvdName;

        DVDTable(String id , String fullname)
        {
            this.dvdID = new SimpleStringProperty(id);
            this.dvdName = new SimpleStringProperty(fullname);
        }

        //dvd ID getters and setters
        public String getID()
        {
            return dvdID.get();
        }
        public void setID(String value)
        {
            dvdID.set(value);
        }
        public StringProperty dvdIDProperty()
        {
            return dvdID;
        }


        //DVD name getters and setters
        public String getName()
        {
            return dvdName.get();
        }
        public void setName(String value)
        {
            dvdName.set(value);
        }
        public StringProperty dvdNameProperty()
        {
            return dvdName;
        }
    }


