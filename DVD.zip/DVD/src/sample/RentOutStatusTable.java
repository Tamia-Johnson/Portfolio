package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RentOutStatusTable {

        private final StringProperty rentout;

        RentOutStatusTable(String rentout)
        {
            this.rentout = new SimpleStringProperty(rentout);
        }


        //Rent getters and setters
        public String getRentout()
        {
            return rentout.get();
        }
        public void setID(String value)
        {
            rentout.set(value);
        }
        public StringProperty RentoutProperty()
        {
            return rentout;
        }




    }


// this creates the rental types within the program