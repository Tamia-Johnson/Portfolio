package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class Rentscreen {

    //define textFields for user input
    @FXML
    public TextField sessionID;
    public TextField updateSessionID;
    public TextField deleteSessionID;
    public Label labelAdd3;
    public Label labelUpdate3;
    public Label labelDelete3;


    private PreparedStatement prep = null;
    private ResultSet result = null;
    private Connection conn = null;
    private ObservableList<RentsTable> dataRents;


    //define an array list for Combo box
    ObservableList clientOptions = FXCollections.observableArrayList();
    ObservableList dvdOptions = FXCollections.observableArrayList();
    ObservableList rentOptions = FXCollections.observableArrayList("Checkout - 3 Day Rental", "Checkout - 7 Day Rental", "Returned", "Overdue");
    ObservableList updateTOptions = FXCollections.observableArrayList();
    ObservableList updateCOptions = FXCollections.observableArrayList();

    //define comboBox for each option
    public ComboBox comboDVD = new ComboBox(dvdOptions);
    public ComboBox comboClient = new ComboBox(clientOptions);
    public ComboBox comboRents = new ComboBox(rentOptions);
    public ComboBox updateComboDVD = new ComboBox(updateTOptions);
    public ComboBox updateComboClient = new ComboBox(updateCOptions);
    public ComboBox updateComboRents = comboRents;

    //define client table
    public TableView<ClientTable> ClientTable;
    public TableColumn<ClientTable, String> colClientID;
    public TableColumn<ClientTable, String> colClientName;
    public TableColumn<ClientTable, String> colClientPhone;

    //define dvd table
    public TableView<DVDTable> DVDTable;
    public TableColumn<DVDTable, String> colDVDID;
    public TableColumn<DVDTable, String> colDVDName;

    //define rent table
    public TableView<RentsTable> RentsTable;
    public TableColumn<RentsTable, String> colSessionNumber;
    public TableColumn<RentsTable, String> colPClientName;
    public TableColumn<RentsTable, String> colPDVDName;
    public TableColumn<RentsTable, String> colRentsName;

    //define rent out table table
    public TableView<RentOutStatusTable> RentOutStatusTable;
    public TableColumn<RentOutStatusTable, String> colRentout;


    //------------------------------------------------------------Rents Scene Buttons---------------------------------------------------------

    //show rentals button
    public void showRentOutStatusListener(ActionEvent actionEvent) {
        colRentout.setCellValueFactory(new PropertyValueFactory<RentOutStatusTable, String>("rentout"));

        RentOutStatusTable.setItems(getRentOutStatus());

    }

    //add rental types into rental table
    public ObservableList<RentOutStatusTable> getRentOutStatus() {
        ObservableList<RentOutStatusTable> rentoutstatus = FXCollections.observableArrayList();
        rentoutstatus.add(new RentOutStatusTable("Checkout - 3 Day Rental"));
        rentoutstatus.add(new RentOutStatusTable("Checkout - 7 Day Rental"));
        rentoutstatus.add(new RentOutStatusTable("Returned"));
        rentoutstatus.add(new RentOutStatusTable("Overdue"));

        return rentoutstatus;
    }

    //show current rental options
    public void showSessionListener(ActionEvent actionEvent) {

        //clear previous values of items in each comboBox and text fields
        comboClient.getItems().clear();
        comboDVD.getItems().clear();
        updateComboClient.getItems().clear();
        updateComboDVD.getItems().clear();
        sessionID.clear();
        updateSessionID.clear();
        deleteSessionID.clear();


        //call below methods to fill in respective comboBox items
        dvdBox();
        clientBox();
        comboRents.setItems(rentOptions);
        updateComboRents.setItems(rentOptions);
        updateClientBox();
        updatedvdBox();


        try {
            Connection conn = SQL.tableConnector();  //connect to database
            dataRents = FXCollections.observableArrayList();
            ResultSet result = conn.createStatement().executeQuery("SELECT * FROM rent"); //make a statement that get information from DB table
            while (result.next()) {
                dataRents.add(new RentsTable(result.getString(1), result.getString(2), result.getString(3), result.getString(4)));  //continue to add information from the DB into table class
            }
            conn.close();
        } catch (Exception e) {
            System.out.println(e);          //print out error e
        }
        colSessionNumber.setCellValueFactory(new PropertyValueFactory<>("sessionID"));    //set sessionID from RentsTable into column session ID
        colPDVDName.setCellValueFactory(new PropertyValueFactory<>("DVDName"));    //set DVDName from RentsTable into column dvd Name
        colPClientName.setCellValueFactory(new PropertyValueFactory<>("clientName"));   //set client name from RentsTable into column client name
        colRentsName.setCellValueFactory(new PropertyValueFactory<>("rentsName"));      //set rents from RentsTable into coloumn rents name

        RentsTable.setItems(null);
        RentsTable.setItems(dataRents);        //put all data gathered from DB into tableview array from scene builder

    }


    //Edit rents button
    public void updateRentListener(ActionEvent actionEvent) {
        try {
            String ID = updateSessionID.getText();
            String dname = updateComboDVD.getSelectionModel().getSelectedItem().toString();
            String cname = updateComboClient.getSelectionModel().getSelectedItem().toString();
            String pname = updateComboRents.getSelectionModel().getSelectedItem().toString();

            String sql = "UPDATE rent SET name = '" + dname + "', clientName ='" + cname + "', rentalStatus = '" + pname + "' WHERE rentalNumber = '" + ID + "'";
            Connection conn = SQL.tableConnector();  //attempt connection to table then perform add method
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            labelUpdate3.setText("Action Completed");
            conn.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //Delete Rents Button
    public void deleteRentButtons(ActionEvent actionEvent) {
        //select only the client ID section and execute deletion that clear everything in that row
        String number = deleteSessionID.getText();
        String sql = "DELETE FROM rent WHERE rentalNumber = '" + number + "' ";
        try {
            Connection conn = SQL.tableConnector();
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            labelDelete3.setText("Action Completed");
            conn.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //create rental Button
    public void createListener(ActionEvent actionEvent) {
        try {
            String ID = sessionID.getText();
            String dname = comboDVD.getSelectionModel().getSelectedItem().toString();   //convert the selected item from comboBox into a string type data.
            String cname = comboClient.getSelectionModel().getSelectedItem().toString();
            String pname = comboRents.getSelectionModel().getSelectedItem().toString();

            String sql = "INSERT INTO rent (rentalNumber,name,clientname,rentalStatus) VALUES('" + ID + "','" + dname + "','" + cname + "','" + pname + "')";
            Connection conn = SQL.tableConnector();  //attempt connection to table then perform add method
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            labelAdd3.setText("Action Completed");
            conn.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }




    //back button
    public void homeListener(ActionEvent actionEvent) throws IOException {
        Parent home = FXMLLoader.load(getClass().getResource("Homescreen.fxml"));
        Scene homescene = new Scene(home);
        Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow(); //this create a Node object that allows you to get the scene and window of another scene
        window.setScene(homescene);
        window.show();
    }

    //Test database connection
    public void ConnectionTest() {
        conn = SQL.tableConnector();
        if (conn == null) {
            System.out.println("Connection failed.");
            System.exit(1);
        } else {
            System.out.println("Connected.");
        }
    }


    //load client name into client comboBox
    public void clientBox() {
        try {
            String query = "SELECT clientName FROM clients";
            prep = conn.prepareStatement(query);
            result = prep.executeQuery();
            while (result.next()) {
                clientOptions.add(result.getString("clientName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        comboClient.setItems(clientOptions);
    }

    //load dvd name into dvd comboBox
    public void dvdBox() {
        try {
            ConnectionTest();
            String query = "SELECT name FROM dvd";
            prep = conn.prepareStatement(query);
            result = prep.executeQuery();
            while (result.next()) {
                dvdOptions.add(result.getString("name"));
            }
            comboDVD.setItems(dvdOptions);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //load dvd name into update dvd comboBox
    public void updatedvdBox() {
        try {
            String query = "SELECT name FROM dvd";
            prep = conn.prepareStatement(query);
            result = prep.executeQuery();
            while (result.next()) {
                updateTOptions.add(result.getString("name"));
            }
            updateComboDVD.setItems(updateTOptions);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //load client name into update client comboBox
    public void updateClientBox() {
        try {
            String query = "SELECT clientName FROM clients";
            prep = conn.prepareStatement(query);
            result = prep.executeQuery();
            while (result.next()) {
                updateCOptions.add(result.getString("clientName"));
            }
            updateComboClient.setItems(updateCOptions);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


//


