package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.*;

public class Clientscreen
{
    @FXML
    public TextField clientID;
    public TextField clientPhone;
    public TextField clientName;
    public TextField updateClientID;
    public TextField updateClientPhone;
    public TextField updateClientName;
    public TextField deleteClientID;
    public Label labelAdd2;
    public Label labelUpdate2;
    public Label labelDelete2;
    private PreparedStatement prep = null;
    private ResultSet result = null;
    private Connection conn = null;
    private SQL dc;
    private ObservableList<ClientTable> data;

    //define a table

    public TableView<ClientTable> ClientTable;

    public TableColumn<ClientTable, String> colClientID;

    public TableColumn<ClientTable, String> colClientName;

    public TableColumn<ClientTable, String> colClientPhone;



//listeners tie actions to the buttons



    //Add client Button
    public void addListener(ActionEvent actionEvent)
    {
        //get user information and create a string method
        String number = clientID.getText();
        String name = clientName.getText();
        String phone = clientPhone.getText();
        String sql = "INSERT INTO clients (clientNumber, clientName, clientPhone) VALUES('"+number+"','"+name+"','"+phone+"')";

        try
        {
            Connection conn = SQL.tableConnector();  //attempt connection to table then perform add method
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            labelAdd2.setText("Action Completed");
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        //clear text entered in these textFields
        clientID.clear();
        clientName.clear();
        clientPhone.clear();
    }

    //Update client Button
    public void updateListener(ActionEvent actionEvent)
    {
        //get info from user input, then create a String query that set the inputted info into database table
        String number = updateClientID.getText();
        String name = updateClientName.getText();
        String phone = updateClientPhone.getText();
        String sql = "UPDATE clients SET clientName ='"+name+"', clientPhone = '"+phone+"' WHERE clientNumber = '"+number+"'";

        try
        {
            //Establish connection to DB then perform update method using String sql from above
            Connection conn = SQL.tableConnector();
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            labelUpdate2.setText("Action Completed");
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        updateClientID.clear();
        updateClientPhone.clear();
        updateClientName.clear();
    }

    //Delete client Button
    public void deleteListener(ActionEvent actionEvent)
    {
        //select only the client ID section and execute deletion that clear everything in that row
        String number = deleteClientID.getText();
        String sql = "DELETE FROM clients WHERE clientNumber = '"+number+"' ";

        try
        {
            Connection conn = SQL.tableConnector();
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            labelDelete2.setText("Action Completed");
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        deleteClientID.clear();

    }

    //load client information Button
    public void loadListener(ActionEvent actionEvent)
    {



        try {
            Connection conn = SQL.tableConnector();  //connect to database
            data = FXCollections.observableArrayList();
            ResultSet result = conn.createStatement().executeQuery("SELECT * FROM clients"); //make a statement that get information from DB table
            while(result.next())
            {
                data.add(new ClientTable(result.getString(1), result.getString(2), result.getString(3)));  //continue to add information from the DB into table class
            }
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println(e);          //print out error e
        }

        colClientID.setCellValueFactory(new PropertyValueFactory<>("clientID"));      //set client ID to column client ID
        colClientName.setCellValueFactory(new PropertyValueFactory<>("clientName"));  //set client full name to column client Name
        colClientPhone.setCellValueFactory(new PropertyValueFactory<>("clientPhone"));  //set client full name to column client Phone

        ClientTable.setItems(null);
        ClientTable.setItems(data);        //put all data gathered from DB into tableview array from scene builder

    }







    //-Scene Transition buttons
    //takes user back home button
    public void homeListener(ActionEvent actionEvent) throws IOException
    {
        Parent home = FXMLLoader.load(getClass().getResource("Homescreen.fxml"));
        Scene homescene = new Scene(home);
        Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); //this create a Node object that allows you to get the scene and window of another scene
        window.setScene(homescene);
        window.show();
    }







    //Test database connection
    public void ConnectionTest()
    {
        conn = SQL.tableConnector();
        if (conn == null)
        {
            System.out.println("Connection not successful.");
            System.exit(1);
        }
        else
        {
            System.out.println("Connection Successful.");
        }
    }


}
