package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Homescreen {

    public void dvdListener(ActionEvent actionEvent) throws IOException
    {
        //load DVD window on clicking the button
        Parent DVD = FXMLLoader.load(getClass().getResource("DVD.fxml"));
        Scene DVDscene = new Scene(DVD);
        Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); //this create a Node object that allows you to get the scene and window of another scene
        window.setScene(DVDscene);
        window.show();

    }

    public void rentListener(ActionEvent actionEvent) throws IOException {
        //load Rents window on clicking the button
        Parent Rents = FXMLLoader.load(getClass().getResource("Rents.fxml"));
        Scene Rentsscene = new Scene(Rents);
        Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); //this create a Node object that allows you to get the scene and window of another scene
        window.setScene(Rentsscene);
        window.show();

    }

    public void clientListener(ActionEvent actionEvent) throws IOException {
        //Load Client window on clicking
        Parent Client = FXMLLoader.load(getClass().getResource("Client.fxml"));
        Scene Clientscene = new Scene(Client);
        Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); //this create a Node object that allows you to get the scene and window of another scene
        window.setScene(Clientscene);
        window.show();
    }
}


// helped by Mariya Kolesnikov and Daniel Lopez