package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RentsTable {


        private final StringProperty sessionID;
        private final StringProperty pdvdName;
        private final StringProperty pclientName;
        private final StringProperty rentsName;

        RentsTable(String id, String dname, String cname, String pname)
        {
            this.sessionID = new SimpleStringProperty(id);
            this.pdvdName = new SimpleStringProperty(dname);
            this.pclientName = new SimpleStringProperty(cname);
            this.rentsName = new SimpleStringProperty(pname);
        }

        //rents getter and setter

        public String getID()
        {
            return sessionID.get();
        }
        public void setID(String value)
        {
            sessionID.set(value);
        }
        public StringProperty sessionIDProperty()
        {
            return sessionID;
        }

        public String getDVDName()
        {
            return pdvdName.get();
        }
        public void setDVDName(String value)
        {
            pdvdName.set(value);
        }
        public StringProperty pDVDNameProperty()
        {
            return pdvdName;
        }

        public String getClientName()
        {
            return pclientName.get();
        }
        public void setClientName(String value)
        {
            pclientName.set(value);
        }
        public StringProperty pClientNameProperty()
        {
            return pclientName;
        }

        public String getRentsName()
        {
            return rentsName.get();
        }
        public void setRentsName(String value)
        {
            rentsName.set(value);
        }
        public StringProperty rentsNameProperty()
        {
            return rentsName;
        }
    }

