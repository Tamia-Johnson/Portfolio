package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ClientTable
{
    private final StringProperty clientID;
    private final StringProperty clientName;
    private final StringProperty clientPhone;

    ClientTable(String id , String fullname, String phone)
    {
        this.clientID = new SimpleStringProperty(id);
        this.clientName = new SimpleStringProperty(fullname);
        this.clientPhone = new SimpleStringProperty(phone);
    }

    //Client ID getters and setters
    public String getID()
    {
        return clientID.get();
    }
    public void setID(String value)
    {
        clientID.set(value);
    }
    public StringProperty clientIDProperty()
    {
        return clientID;
    }


    //Client name getters and setters
    public String getName()
    {
        return clientName.get();
    }
    public void setName(String value)
    {
        clientName.set(value);
    }
    public StringProperty clientNameProperty()
    {
        return clientName;
    }

    //client phone gettes and setters
    public String getPhone()
    {
        return clientPhone.get();
    }
    public void setPhone(String value)
    {
        clientPhone.set(value);
    }
    public StringProperty clientPhoneProperty()
    {
        return clientPhone;
    }

}

