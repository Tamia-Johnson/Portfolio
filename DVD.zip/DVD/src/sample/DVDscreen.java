package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DVDscreen {



        @FXML
        public TextField DVDID;
        public TextField DVDName;
        public TextField updateDVDID;
        public TextField updateDVDName;
        public TextField deleteDVDID;
        public Label labelAdd;
        public Label labelUpdate;
        public Label labelDelete;
        private PreparedStatement prep = null;
        private ResultSet result = null;
        private Connection conn = null;
        private Statement stmt = null;
        private SQL dc;
        private ObservableList<DVDTable> data;

        //define a table

        public TableView<DVDTable> DVDTable;

        public TableColumn<DVDTable, String> colDVDID;

        public TableColumn<DVDTable, String> colDVDName;



        //Add DVD Button
        public void AddListener(ActionEvent actionEvent)
        {
            //get user information and create a string method
            String number = DVDID.getText();
            String name = DVDName.getText();
            String sql = "INSERT INTO dvd (number, name) VALUES('"+number+"','"+name+"')";

            try
            {
                Connection conn = SQL.tableConnector();  //attempt connection to table then perform add method
                Statement stmt = conn.createStatement();
                stmt.executeUpdate(sql);

                labelAdd.setText("Action Completed");
                conn.close();

            }
            catch(Exception e)
            {
                System.out.println(e);
            }

            DVDID.clear();
            DVDName.clear();
        }

        //Update DVD Button all updating is done in SQL
        public void UpdateListener(ActionEvent actionEvent)
        {
            //get info from user input, then create a String query that set the inputted info into database table
            String number = updateDVDID.getText();
            String name = updateDVDName.getText();
            String sql = "UPDATE dvd SET name='"+name+"' WHERE number = '"+number+"'";

            try
            {
                //Establish connection to DB then perform update method using String sql from above
                Connection conn = SQL.tableConnector();
                Statement stmt = conn.createStatement();
                stmt.executeUpdate(sql);
                labelUpdate.setText("Action Completed");
                conn.close();

            }
            catch(Exception e)
            {
                System.out.println(e);
            }

            updateDVDID.clear();
            updateDVDName.clear();
        }

        //Delete DVD Button
        public void DeleteListener(ActionEvent actionEvent)
        {
            //select only the dvd ID section and execute deletion that clear everything in that row
            String number = deleteDVDID.getText();
            String sql = "DELETE FROM dvd WHERE number = '"+number+"'";

            try
            {
                Connection conn = SQL.tableConnector();
                Statement stmt = conn.createStatement();
                stmt.executeUpdate(sql);

                labelDelete.setText("Action Completed");
                conn.close();
            }
            catch(Exception e)
            {
                System.out.println(e);
            }

            deleteDVDID.clear();
        }

        //Show current DVDs
        public void showListener(ActionEvent actionEvent)
        {
            try {
                Connection conn = SQL.tableConnector();  //connect to database
                data = FXCollections.observableArrayList();
                ResultSet result = conn.createStatement().executeQuery("SELECT * FROM dvd"); //make a statement that get information from DB table
                while(result.next())
                {
                    data.add(new DVDTable(result.getString(1), result.getString(2)));  //continue to add information from the DB into table class
                }
                conn.close();
            }
            catch(Exception e)
            {
                System.out.println(e);          //print out error e
            }

            colDVDID.setCellValueFactory(new PropertyValueFactory<>("dvdID"));      //set dvd ID to column dvd ID
            colDVDName.setCellValueFactory(new PropertyValueFactory<>("dvdName"));  //set dvd full name to column dvd Name

            DVDTable.setItems(null);
            DVDTable.setItems(data);        //put all data gathered from DB into tableview array from scene builder


        }
        //--------------------------------------------------------------------------------------------------------------------------





        // transitions buttons for home

        //back button
        public void homeListener(ActionEvent actionEvent) throws IOException
        {
            Parent home = FXMLLoader.load(getClass().getResource("Homescreen.fxml"));
            Scene homescene = new Scene(home);
            Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); //this create a Node object that allows you to get the scene and window of another scene
            window.setScene(homescene);
            window.show();
        }




        //Test database connection
        public void ConnectionTest()
        {
            conn = SQL.tableConnector();
            if (conn == null)
            {
                System.out.println("Connection not successful.");
                System.exit(1);
            }
            else
            {
                System.out.println("Connection Successful.");
            }
        }

    }


